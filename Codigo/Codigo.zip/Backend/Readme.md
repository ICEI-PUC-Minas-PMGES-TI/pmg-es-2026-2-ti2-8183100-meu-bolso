# Meu Bolso — Back-end

API REST do **Meu Bolso**: autenticação de usuários com JWT e persistência em MongoDB.

## Tecnologias

- **Java 21** e **Spring Boot 3.3**
- **Spring Web** (API REST) e **Spring Security** (autenticação)
- **Spring Data MongoDB** (persistência)
- **JWT** com [jjwt](https://github.com/jwtk/jjwt) 0.12
- **spring-dotenv** (lê o `.env` em desenvolvimento local)
- **Bean Validation** (validação dos dados de entrada)

## Pré-requisitos

- Java 21 (JDK)
- Docker (para o MongoDB) ou um MongoDB local na porta `27017`
- O wrapper do Maven (`mvnw` / `mvnw.cmd`) já acompanha o projeto — não é preciso instalar o Maven.

## Variáveis de ambiente

Copie `.env.example` para `.env` e preencha. O `.env` **não** é versionado.

| Variável | Obrigatória | Padrão (dev) | Descrição |
|---|---|---|---|
| `APP_JWT_SECRET` | Sim | — | Segredo de assinatura do JWT (mínimo **32 caracteres**). |
| `MONGODB_URI` | Não | `mongodb://localhost:27017/meubolso` | String de conexão do MongoDB. |
| `APP_JWT_EXPIRATION_MS` | Não | `86400000` (24h) | Validade do token, em milissegundos. |
| `APP_FRONTEND_URL` | Não | `http://localhost:5173` | URL do front-end. |

## Como executar

### Opção A — tudo no Docker

```bash
cp .env.example .env     # defina APP_JWT_SECRET
docker compose up -d     # sobe MongoDB + back-end
```

### Opção B — MongoDB no Docker, back-end local

```bash
cp .env.example .env
docker compose up -d mongodb
./mvnw spring-boot:run   # Windows: mvnw.cmd spring-boot:run
```

A API fica disponível em `http://localhost:8080`.

### Testes

```bash
./mvnw test              # Windows: mvnw.cmd test
```

## Autenticação

A API usa **JWT Bearer**. As rotas em `/api/auth/**` são públicas; todas as
demais exigem o cabeçalho:

```
Authorization: Bearer <token>
```

O token é obtido no login e identifica o usuário pelo e-mail.

## Endpoints

### Autenticação — `/api/auth` (público)

| Método | Rota | Descrição |
|---|---|---|
| `POST` | `/api/auth/register` | Cadastra um usuário (nome, e-mail, telefone, senha). |
| `POST` | `/api/auth/login` | Autentica e retorna o token JWT. |

### Usuário autenticado — `/api/usuarios` (requer token)

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/api/usuarios/me` | Dados do usuário logado. |
| `PUT` | `/api/usuarios/me` | Atualiza nome, telefone e e-mail (reemite o token). |
| `PUT` | `/api/usuarios/me/senha` | Troca a senha (exige a senha atual). |

### Metas — `/api/metas` (requer token)

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/api/metas` | Lista as metas do usuário. |
| `POST` | `/api/metas` | Cria uma meta (nome, valorAlvo, prazo, prioridade). |
| `PUT` | `/api/metas/{id}` | Edita os dados da meta (não altera o valor acumulado). |
| `DELETE` | `/api/metas/{id}` | Exclui a meta. |

### Carteira — `/api/carteiras` (requer token)

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/api/carteiras` | Retorna a carteira do usuário (vazia se ainda não existir). |
| `PUT` | `/api/carteiras` | Substitui as listas. Exige a `versao` atual (409 se desatualizada) e valida os itens (400). |

### Gastos — `/api/gastos` (requer token)

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/api/gastos` | Lista os gastos; antes gera as recorrências vencidas. |
| `POST` | `/api/gastos` | Cria um gasto (opcionalmente recorrente) e ajusta o saldo da carteira. |
| `PUT` | `/api/gastos/{id}` | Edita o gasto e reajusta o saldo. |
| `PATCH` | `/api/gastos/{id}/comentario` | Atualiza só o comentário. |
| `DELETE` | `/api/gastos/{id}` | Exclui o gasto e estorna o saldo. |
| `GET` | `/api/gastos/recorrentes` | Lista as regras de recorrência. |
| `PUT` | `/api/gastos/recorrentes/{id}` | Edita uma regra. |
| `DELETE` | `/api/gastos/recorrentes/{id}` | Exclui uma regra. |

### Orçamento — `/api/orcamento` (requer token)

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/api/orcamento` | Retorna o teto mensal. |
| `PUT` | `/api/orcamento` | Define o teto mensal. |

## Testes

Testes unitários (JUnit 5 + Mockito + AssertJ) das regras de saldo e de metas. Não precisam de MongoDB nem do back-end no ar.

| Classe | O que cobre |
|---|---|
| `CarteiraServiceTest` | Gasto em conta, crédito e débito, estorno, dinheiro físico intocado, entradas inválidas, `saldoDe` e `ajustarSaldo` |
| `MetaServiceTest` | Depósito e retirada de meta, saldo insuficiente, carteira inválida, falha ao ajustar a carteira, meta de outro usuário (404) |

### Como executar

Pré-requisito: JDK 21. No PowerShell, a partir da raiz do repositório:

```powershell
cd Codigo\Backend
.\mvnw.cmd test "-Dtest=CarteiraServiceTest,MetaServiceTest"
```

As aspas são obrigatórias no PowerShell por causa da vírgula. No Linux/macOS: `./mvnw test -Dtest=CarteiraServiceTest,MetaServiceTest`.

Resultado esperado:

```
Tests run: 22, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

Em caso de falha, o Maven mostra o nome do teste e o valor esperado contra o obtido.

> `.\mvnw.cmd test` sem filtro também roda `MeuBolsoApplicationTests`, que sobe o Spring e exige MongoDB e as variáveis do `.env` disponíveis.

## Estrutura do código

```
src/main/java/Projeto/MeuBolso/
  Config/        Configuração de segurança (SecurityConfig)
  controller/    Endpoints REST (Auth, Usuario, Meta, Gasto, Orcamento, Carteira)
  model/         Entidades e DTOs (Usuario, Meta, Gasto, Recorrencia, Orcamento, CarteiraUsuario, *Dtos)
  repository/    Repositórios Spring Data MongoDB
  security/      Filtro de autenticação JWT
  service/       Token, UserDetailsService, recorrência de gastos e ajuste de saldos da carteira
```
